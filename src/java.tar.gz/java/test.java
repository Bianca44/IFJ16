class tt { static int p(int a, int b, String g){

                if (9) a = 5;
                while (1) {
                    //{return 9;return 9;return 9;}
                    k(5,5,6);
                    b = 9+6;
                    //{return 9;return 9;return 9;}
                    return 9;
                }
                    if (9) {
                        //{return 9;return 9;return 9;}
                        k(5,5,6);
                        b = 9+6;
                        //{return 9;return 9;return 9;}
                        return 9;
                    }

                    if (9) int a = 5;
                    {
                        //{return 9;return 9;return 9;}
                        k(5,5,6);
                        b = 9+6;
                        //{return 9;return 9;return 9;}
                        return 9;
                    }
                    int a = 9;
                    return 9;
                {return 9;return 9;return 9;}
                //if (9) ;
                a = 5;
                while (1) a = a+5;
                int a = 5;
                {return 9;return 9;return 9;}
                {return 9;return 9;return 9;}
                   k(5,5,6);
                   double a = 5;
                   return 9;
                   {{{return 9;return 9;}}}
                   b = 9+6;
                   //;
                   return 9+5;
           }
           static int c = 42;
           static void x() {
           }
           static int d;
           static int k = 42;
		   static int c = 42;
           static int p() {
           }
}
