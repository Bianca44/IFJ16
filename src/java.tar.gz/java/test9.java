class Main { //static int a = (5+5;
             static int run () {
                    if (5+5) {

                    }

                    int a = Main.a(12-9);
                    int b = Main.a(12*9);
             }

             static int a () {

             }
}
