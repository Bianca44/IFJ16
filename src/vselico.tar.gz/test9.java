class Main {
    //static int c = 9;
    static void run () {
        //ifj16.readInt();
        ifj16.readInt();
        //ifj16.readInt();
        //ifj16.print("Ahoj\nSve'te\\\042");
    }

}
