class Main {

    static double f = 2;
    static double a = 5 + f;
    static void run() {
        double x = ifj16.readInt();
        ifj16.print(x+2.4);

        double s = 2;
        double i = s + 3;
        ifj16.print("i="+i);

        int o = 6;
        int r = 12;
        pp(o, r);
}
    static int pp (double a, double b) {
        ifj16.print("\n" +" kk "+a+"\n");
        ifj16.print(a+6.6+"\n");
        ifj16.print("\n" +" kk "+b+"\n");
        ifj16.print(b+6.6+"\n");
        return 1;
    }

}
