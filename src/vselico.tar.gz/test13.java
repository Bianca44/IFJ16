class Main {
	static boolean c = 8 <= 8;
    static int a = 5+5;
    static void run () {

    		//ifj16.print("Hello world");
            ifj16.print(a);
            ifj16.print(c);


    }

    static void pp() {
        ifj16.print("Kokotina");
    }

}
