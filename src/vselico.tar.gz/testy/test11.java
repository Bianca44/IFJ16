//error 2 
class Main
{
    static void run() {
    	double a = 199.e+23; //spravne napr 199.99e+9
    }
}
