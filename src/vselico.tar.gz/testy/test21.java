//error 4
class Main
{
    static void run()
    {
     String s = "Ahoj";
     if (s) {
     	int a = 0;
     }

     else {
     	int b = 9;
     }
    }
}
