//vypise 5 !
class Main
{
    static void run() {
    	static int a = 9; 
    	int a = 5;

    	ifj16.print("a = " +a);
    }
}
