class Main{
//    static int y=0;
    static void run(){
       // int x = 0;
       // String a;
        //a = ifj16.readString();
//        ifj16.length("ass");
      //  ifj16.print(x+"\n");
        return ;

    }

}
