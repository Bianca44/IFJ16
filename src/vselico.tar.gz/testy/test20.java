//error 3
class Main
{
    static void run()
    {
     int a = 7;

     else if (a=7) { //bez predchadzajuceho if
     	a = 9;
     }

    }
}
