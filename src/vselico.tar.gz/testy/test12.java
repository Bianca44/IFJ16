//error 2
class Main
{
    static void run() {
     int a = 0.888e+99; //DOUBLE
    }
}
