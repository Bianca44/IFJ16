//error 8

class Main {
	static void run() {

		int a;
		int b = 7;
		int c = 8;

		int count_1 = vypocet_1 (a,b,c);
		ifj16.print("Vysledok =" +count_1);
	}

	static void vypocet_1 (int p, int q, String r) {
		return;	
	}
}

	