//error 3
class Main
{
    int a = 5;
    return;
}
