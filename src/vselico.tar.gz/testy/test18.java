//error 8 - void nevraca hodnotu

class Main {
	static void run() {

		int a = 9;
		int b = 7;
		int c = 8;

		int count_1 = 0;

		int count_1 = vypocet_1 (a,b,c);
		ifj16.print("Vysledok =" +count_1);
	}

	static void vypocet_1 (int p, int q, String r) {
		return (p+q+r); 	
	}
}

	
