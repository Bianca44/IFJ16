class Main
{
    static void run()
    {
     int boolean = 0;
     int vysledok = boolean + 0;
    }
}
