//error 2
class Main
{
    static void run()
    {
     int a = 8;
     int c = 9;
     int b = int a;
    }
}
