class Main
{
    static void run()
    {
     int a = 98 /*blablabla*/; //spravny tvar!
    }
}
