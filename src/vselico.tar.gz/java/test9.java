class Main {

    static void run () {
            int a;
            {
                {}
                a = 5;
            }
String p = 0;
            int l = ifj16.sort(p);
            //int b = play("h", "h");
            if (9) {
                {
                    {}
                    a = 5+3;
                }
            }

            //s = 9;
           // ifj16.print("Pozice retezce \"text\" v retezci str2: " + a + "\n");
    }
    static void play(String b, String a) {
        int k;
    }
    //static int x = 1+ Main.play;

}
