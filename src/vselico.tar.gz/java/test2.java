class Main
{
static void run
        ()
{
        int a = 5;
while (9) { }
        /*if (9) {;return 9; a = 5;}
        if (9) if (9) {};
        if (9) while (9) {};
        while (9) if (9) {};
        while (9) ;
        while (9) {}
        if (9) ; else ;
        if (9) {}
        if (9) {} else {}
        if (9) return 9;
        a = 5;
        if (9) {} else ;
        if (9) ;
        if (9) ; else {}
        ;
        ;*/
        //;
}
}
