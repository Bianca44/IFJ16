class Main{
    static int y=0;
    static void run(){
        int x = 0;
        x = x();
        ifj16.print(x);
        return ;

    }

    static int x(){
        while(y < 10) return 9;

    }
}
