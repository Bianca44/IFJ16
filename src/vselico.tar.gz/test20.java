class Main{

    static int a;
    static void run(){
			boolean faszom = true;
		boolean baszdmeg = true;
        if(faszom || baszdmeg && ((5+(8-1))>0)){
            ifj16.print("DDD");
        }


    }

}
