class Main
{
    static int x;
static void run()
{
    String str1;
    str1 = "Toto je nejaky text";
    Main.x = ifj16.find(str1, "text");
    ifj16.print(Main.x);
}
}
