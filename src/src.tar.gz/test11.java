class Main {
static void run () {
        ifj16.print("Hello world");
        //int a;
        //a = run();
        int a = ab();
}

static int ab() {
    return 1;
}

}
