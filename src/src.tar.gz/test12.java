class Main {
    static void run () {

    		ifj16.print("Hello world");
            int i = 2;
            ifj16.print("test" + i);
             pp();
    }

    static void pp(String a) {
        ifj16.print("Kokotina");
    }

}
