class Main {

    //static double t = 6.5 + 3.5;
   // static String k =  5.36 + "ahoj" + "devet" ;
	//static int g = 3;
	//static int j = 2*3+2*2;
	/*static int m = 5+5;*/
    static void run () {

    	ifj16.print("Hello world" + 42);
    /*	int f = 2*2+2*2;
    	ifj16.print(j);
    	ifj16.print(Main.j);
    	int a;
    	a = aa(true, "odkaz z main runu");
        ifj16.print(a);
		ifj16.print(j);
	}
*/
/*	static void pp() {
        ifj16.print("Kokotina");
    }*/

   /* static int aa(boolean e, String msg) {
    	ifj16.print("druha funkcia");
    	ifj16.print(e);
    	ifj16.print(msg);
    	return 5;
    }*/
}
}