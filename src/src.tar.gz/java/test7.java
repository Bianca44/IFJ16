class Main
{
    static int a = 4 ;

    static void a () {
        //a = 5;
    }
}
