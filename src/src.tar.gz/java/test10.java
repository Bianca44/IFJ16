class Main {
    static void run() {}
    /*static int a(String b) {
        int a;
        boolean c;
        return 1;
    }*/
}
