class Main
{
static int x;
static void run()
{
        String str1;
        str1 = "Toto je nejaky text";
        String str2;
        str2 = str1 + ", ktery jeste trochu obohatime";
        //Main.x = ifj16.find(str2, "text");
        //ifj16.print("Pozice retezce \"text\" v retezci str2: " + x + "\n");
        Game.play(str1);
}
// end of static void run()
}
