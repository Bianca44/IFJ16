//ERROR 4, zly typ parametra pri volani fcie

class Main {
	static void run() {

		int a;
		int b;
		int c;

		//ifj16.print("Zadejte 1.cislo: ");
        a = 7;//ifj16.readInt();
        //ifj16.print("Zadejte 2.cislo: ");
        b = 8;//ifj16.readInt();
        //ifj16.print("Zadejte 3.cislo: ");
        c = 9;//ifj16.readInt();

		int count_1 = vypocet_1 (a,b,c);
		ifj16.print("Vysledok =" +count_1);
	}

	static void vypocet_1 (int p, int q, String r) {
		return;	
	}
}

	