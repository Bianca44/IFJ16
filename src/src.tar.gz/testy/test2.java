//ERROR 2

class Main {
	static void run() {

	int a = 7;
	int b = 9;
	int vysledok = a+b;
}