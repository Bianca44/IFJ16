class Main {
    static void run() {
        {   // here shall be '}'
    }
}
