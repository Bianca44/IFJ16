class Main {
    static int return = 5;
    
    static void run() {
    }
}