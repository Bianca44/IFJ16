class Main {
    static int a = 52;
    static void run() {
        if (5+3 > +5) {}
    }
}
