class Main {
    static int static = 5;
    
    static void run() {
    }
}