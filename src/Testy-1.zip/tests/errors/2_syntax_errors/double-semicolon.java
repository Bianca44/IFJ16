class Main {
    static run() {
        int a;; // double semicolon
    }
}
