class Main {
    static int double = 5;
    
    static void run() {
    }
}