class Main {
    static void run() {
        String a = "str";
        if() { // and with a different type than boolean

        }
        
    }
}