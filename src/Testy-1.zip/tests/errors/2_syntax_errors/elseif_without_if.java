class Main {
    static void run() {
        else if{  // else without if
            ;
        }
    }
}
