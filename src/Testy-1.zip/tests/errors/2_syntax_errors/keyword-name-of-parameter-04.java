class Main {
    static int continue = 5;
    
    static void run() {
    }
}