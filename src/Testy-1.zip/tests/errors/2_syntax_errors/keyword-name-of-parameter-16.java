class Main {
    static int while = 5;
    
    static void run() {
    }
}