class Main {
    static void run() {
        void a;
    }
}
