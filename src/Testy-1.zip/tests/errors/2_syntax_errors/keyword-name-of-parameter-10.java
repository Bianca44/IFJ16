class Main {
    static int int = 5;
    
    static void run() {
    }
}