class Main {
    static void run() {
        int a;
        while (a == 2 ) {
            int b;  // declaration inside block
        }
    }
}
