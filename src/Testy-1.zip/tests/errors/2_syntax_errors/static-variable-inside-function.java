class Main {
    static void run() {
        static int var; // static variable inside function 
    }
}
