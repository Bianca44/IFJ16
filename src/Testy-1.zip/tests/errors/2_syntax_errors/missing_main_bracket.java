class Main // missing '{'
    static void run() {
        int a;
        int b;
    }
}