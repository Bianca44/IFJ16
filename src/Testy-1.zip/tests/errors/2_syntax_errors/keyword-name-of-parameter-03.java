class Main {
    static int class = 5;
    
    static void run() {
    }
}