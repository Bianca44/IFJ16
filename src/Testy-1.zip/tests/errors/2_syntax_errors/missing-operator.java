class Main {
    static void run(int) { // missing parameter name
        int b = 12 34;
    }
}
