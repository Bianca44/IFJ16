class Main {
    static void a;
    static void run() {
    }
}
