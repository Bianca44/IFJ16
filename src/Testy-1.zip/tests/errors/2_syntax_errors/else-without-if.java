class Main {
    static void run() {
        else {  // else without if
            ;
        }
    }
}
