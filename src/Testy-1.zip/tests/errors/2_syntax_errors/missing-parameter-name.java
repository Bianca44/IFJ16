class Main {
    static void run(int) { // missing parameter name
        
    }
}
