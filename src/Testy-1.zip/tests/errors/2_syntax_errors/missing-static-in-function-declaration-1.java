//viz 3) in https://wis.fit.vutbr.cz/FIT/st/phorum-msg-show.php?id=45258
class Main {
    static void run() {
    	bar.foo();
    }
}

class bar {
    void foo() {} //function declaration without static
}