class Main {
    static void run() {
        String a = "str";
        if(true && && ) { // and with a different type than boolean

        }
        
    }
}