class Main {
    static void run(test) { // missing parameter name
        
    }
}