class Main {
    static int foo (int a {}
}
