class Main {
    static void run() {
        int a = 5;
        int b = 10;
        if(a === b) { // three equals signs

        }
        
    }
}