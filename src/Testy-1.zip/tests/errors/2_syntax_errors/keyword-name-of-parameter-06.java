class Main {
    static int else = 5;
    
    static void run() {
    }
}