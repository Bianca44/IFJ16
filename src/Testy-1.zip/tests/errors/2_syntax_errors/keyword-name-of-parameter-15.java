class Main {
    static int void = 5;
    
    static void run() {
    }
}