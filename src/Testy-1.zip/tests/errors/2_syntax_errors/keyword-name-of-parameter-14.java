class Main {
    static int true = 5;
    
    static void run() {
    }
}