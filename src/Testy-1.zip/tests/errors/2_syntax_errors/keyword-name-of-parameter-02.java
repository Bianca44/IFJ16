class Main {
    static int break = 5;
    
    static void run() {
    }
}