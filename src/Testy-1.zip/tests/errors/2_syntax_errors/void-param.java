class Main {
    static void run (int a, void b){}
}
