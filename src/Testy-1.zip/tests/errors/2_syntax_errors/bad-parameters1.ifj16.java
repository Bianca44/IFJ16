class Main {
    static int foo (,) {}
}
