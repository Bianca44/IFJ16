class Main {
    static int if = 5;
    
    static void run() {
    }
}