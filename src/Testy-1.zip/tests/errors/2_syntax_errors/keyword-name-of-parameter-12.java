class Main {
    static int String = 5;
    
    static void run() {
    }
}