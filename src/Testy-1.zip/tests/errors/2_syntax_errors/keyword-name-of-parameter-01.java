class Main {
    static int boolean = 5;
    
    static void run() {
    }
}