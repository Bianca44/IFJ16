class Main {
    static void run() {
        int b = 1 < 2 < 3;
    }
}
