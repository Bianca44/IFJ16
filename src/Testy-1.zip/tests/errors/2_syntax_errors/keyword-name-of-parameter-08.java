class Main {
    static int for = 5;
    
    static void run() {
    }
}