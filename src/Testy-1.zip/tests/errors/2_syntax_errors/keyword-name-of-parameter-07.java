class Main {
    static int do = 5;
    
    static void run() {
    }
}