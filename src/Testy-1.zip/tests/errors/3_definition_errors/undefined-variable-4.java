class Main {
    static void run() {
    	int a;
        bar.foo(a);
    }
}

class bar {
    static void foo(int a) {
        ifj16.print("int: " + number); // variable undeclared
    }
}