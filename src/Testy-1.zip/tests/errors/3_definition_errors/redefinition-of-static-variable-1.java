class Main {
    static int a;
    static int a;
    static void run() {
        a = a + b;
        b = a + b;
    }
}
