class Main {
	static int a;
    static void run() {}
    static int brun() {
        return b; // returning undeclared variable
    }
}
