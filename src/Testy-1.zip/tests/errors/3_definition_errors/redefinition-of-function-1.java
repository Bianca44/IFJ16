class Main {
    static void run() {
        int a;
        int b;
    }
    static int run; // redefinition of run
}
