class Main {
    static void run() {
        int a;
        int b;
    }
    static int test(int a) {
        
    }
    static int test(int a) {
        
    }
}
