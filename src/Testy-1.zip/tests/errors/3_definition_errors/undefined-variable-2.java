class Main {
    static void run() {
        int a;
        int b;
        a = a + b;
        c = a + b; // undefined c
    }
}
