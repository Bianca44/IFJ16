class Main {
    static void run() {
        int a;
        int b;
    }
}
class ifj16 {
    static int test(int a) {
        
    }
}
