class Main {
    static void run() {
        int a;
        int b;
    }
    static int a;
    static int a; // redefinition of static variable
}
