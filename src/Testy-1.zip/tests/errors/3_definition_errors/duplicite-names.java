// Definovanie premennej a funkcie s rovnakym menom
// Autor testu: https://github.com/H00N24/ifj_tester/commit/4d5105d

class Main
{
    static void run()
    {
        int redefine = 2;
    }

    static void redefine(int a)
    {
    	// prazdna
    }
}
