class Main {
    static void run() {
        int a;
        int b;
        a = a + b;
        ifj16.find(c, a); // c- undefined
    }
}
