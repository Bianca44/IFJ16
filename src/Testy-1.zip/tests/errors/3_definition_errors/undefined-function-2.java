class Main {
    static void run() {
        int a;
        int b;
        a = a + b;
        ifj16.printf(c, a); // printf undefined
    }
}
