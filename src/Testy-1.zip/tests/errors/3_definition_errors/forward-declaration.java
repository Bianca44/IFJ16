class Main {
    static void run() {
        int a;
        int b;
        c = a;  // forward declaration
        int c;
    }
}
