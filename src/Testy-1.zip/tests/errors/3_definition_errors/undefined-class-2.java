class Main {
    static void run() {
        int a;
        ifj.readInt(); // ifj undefined
    }
}
