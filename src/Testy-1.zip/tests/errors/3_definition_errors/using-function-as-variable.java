class Main {
    static int p = 3;
    static void run() {
        int a;
        int b;
        p = b;
        run = a;    // run is not variable
    }
}
