class Main {
    static void run() {
        myclass.a = 5;  // undefined class
    }
}
