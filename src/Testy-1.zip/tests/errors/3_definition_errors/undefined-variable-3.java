class Main {
    static void run() {
        ifj16.print("int: " + number); // variable undeclared 
    }
}