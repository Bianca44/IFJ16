class Main {
    static void run() {
        int a;
        int b;
    }
}
class Main {
    static int test(int a) {
        
    }
}
