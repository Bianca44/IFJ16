class Main {
    static void run() {
        int a;
        int b;
    }
    static void run() {
        ifj16.print("Ahoj\n");
    }
}
