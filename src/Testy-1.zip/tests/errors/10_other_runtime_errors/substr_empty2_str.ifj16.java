class Main {
    static void run() {
        ifj16.substr("", 1, 0);
    }
}
