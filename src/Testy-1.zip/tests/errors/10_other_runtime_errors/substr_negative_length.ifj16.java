class Main {
    static void run() {
        int a = 0 - 1;
        ifj16.substr("substr", 2, a);
    }
}
