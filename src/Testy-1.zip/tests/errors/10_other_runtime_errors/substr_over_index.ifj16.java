class Main {
    static void run() {
        ifj16.substr("substr", 5, 2);
    }
}
