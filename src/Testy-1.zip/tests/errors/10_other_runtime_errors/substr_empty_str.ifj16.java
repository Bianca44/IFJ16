class Main {
    static void run() {
        ifj16.substr("", 0, 1);
    }
}
