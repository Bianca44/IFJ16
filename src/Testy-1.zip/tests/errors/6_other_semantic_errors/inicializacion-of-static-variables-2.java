class Main {
    // Viz https://wis.fit.vutbr.cz/FIT/st/phorum-msg-show.php?id=45741
    static double a = b;
    static double b = a;
    static void run() {
        ifj16.print("Ahoj\n");
    }
}
