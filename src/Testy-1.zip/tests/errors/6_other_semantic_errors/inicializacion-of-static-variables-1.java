class Main {
    // Viz https://wis.fit.vutbr.cz/FIT/st/phorum-msg-show.php?id=45741
    static int a = b;
    static int b = 42;
    static void run() {
        ifj16.print("Ahoj\n");
    }
}
