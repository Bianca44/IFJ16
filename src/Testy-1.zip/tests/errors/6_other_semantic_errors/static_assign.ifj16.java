class Main {
    static int a = b;
    static int b = 5;
    static void run() {}
}
