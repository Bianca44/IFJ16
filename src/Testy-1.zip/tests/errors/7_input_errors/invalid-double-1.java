class Main {
    static void run() {
        double a = ifj16.readDouble();
    }
}
