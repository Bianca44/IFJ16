class Main {
    static void run() {
        double d = 1.1ex; // lex_error
    }
}