class Main {
    static void run() {
        String s = "\