class Main {
    static void run() {
        double x = 52.1E-+5;
    }
}
