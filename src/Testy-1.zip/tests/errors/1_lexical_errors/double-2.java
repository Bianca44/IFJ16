class Main {
    static void run() {
        double d = 1.; // lex_error
    }
}