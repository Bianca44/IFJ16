class Main {
    static void run() {
        double x = .;
    }
}
