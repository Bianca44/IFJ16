class Main {
	static void run() {
		int a = 3;
	}
}
/*