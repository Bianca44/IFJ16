class Main {
    static void run() {
        int a;
        int b;
    }
    static int ?; // lexical error 
}
