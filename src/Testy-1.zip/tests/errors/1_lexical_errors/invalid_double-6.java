class Main {
    static void run() {
        double x = 1.5.5;
    }
}
