class Main {
    static void run() {
        int \a = 5; // lex error
    }
}
