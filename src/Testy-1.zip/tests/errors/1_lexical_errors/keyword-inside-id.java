class Main {
    static void run() {
        int a;
        int b;
        ifj16.class; // keyword in id
    }
}
