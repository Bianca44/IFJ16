class Main {
    static void run() {
        int abcd?defg; // lex error
    }
}

class foo {
    static void bar() {}
}
