class Main {
    static void run() {
        double a = 5;
        double x = 3.a;
    }
}
