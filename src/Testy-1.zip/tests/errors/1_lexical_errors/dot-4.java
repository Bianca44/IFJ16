class Main {
    static void run() {
        foo. ; // lex_error
    }
}

class foo {
    static void bar() {}
}
