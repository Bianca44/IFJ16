class Main {
    static void run() {
        double d = 1.e; // lex_error
    }
}