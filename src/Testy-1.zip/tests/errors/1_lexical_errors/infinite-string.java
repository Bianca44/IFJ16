class Main {
    static void run() {
        String s = "Překvapivě dlouuuuuhej řetězec;
    }
}
