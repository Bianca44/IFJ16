class Main {
    static void run() {
        .bar; // lex_error
    }
}

class foo {
    static void bar() {}
}
