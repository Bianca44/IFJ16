class Main {
    /*
     * Já jsem komentář, kterej nikde nekončí...
     *
}
