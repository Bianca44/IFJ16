class Main {
    static String a;
    static void run() {}
    static void run2(int a, double b) {
        ifj16.compare("fdas", "__", a); // invalid parameter count
    }
}

