class Main {
	static String a;
    static void run() {
        a = ifj16.find("str1", "t"); // lvalue is string
    }
}