class Main {
    static void run() {
        String a;
        a = 5;	// rvalue is int
    }
}