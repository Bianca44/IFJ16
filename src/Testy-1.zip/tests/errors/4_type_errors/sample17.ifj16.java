class Main {
    static String a;
    static void run(){}
    static void ru1n(int a, double b) {
        Main.a = ifj16.substr("bcd", a) ; // wrong list of parameters
    }
}

