class Main
{
	static void run()
	{
		double a = 0.1;
		int b = 17 / a;
		/*
		 * a je double, tj. 5 / a je double, tj. snažíme se do int uložit
		 * hodnotu double
		 */
	}
}
