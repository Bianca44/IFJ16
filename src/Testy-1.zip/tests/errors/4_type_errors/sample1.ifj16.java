class Main {
    static void run() {
        ifj16.sort(); // wrong number of params
    }
}
