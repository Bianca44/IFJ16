class Main { 
    static void run() {
    	int b = 5;
        boolean a = b; // int to boolean
    }
}