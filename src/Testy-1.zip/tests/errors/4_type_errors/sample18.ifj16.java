class Main {
    static String a;
    static void run() {}
    static void run2(int a, double b) {
        a = ifj16.substr("bb", 2, b) ; // wrong type of last argument
    }
}

