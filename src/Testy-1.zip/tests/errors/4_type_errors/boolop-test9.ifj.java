class Main { 
    static void run() {
        boolean a = 5; // int to boolean
    }
}