class Main { 
    static void run() {
    	double b = 5.5;
        boolean a = b; // double to boolean
    }
}