class Main {
    static void run() {
        String a = "str";
        if(a) { // using String as a logical operator

        }
        
    }
}