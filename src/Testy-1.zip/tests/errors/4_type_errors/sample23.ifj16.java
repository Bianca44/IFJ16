class Main {
    static void run() {
        double a;
        ifj16.length(a); // wrong type of parameter
    }
}