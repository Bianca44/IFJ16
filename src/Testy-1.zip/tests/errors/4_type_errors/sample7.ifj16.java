class Main {
    static void run() {
        String a = ifj16.sort("stuff");
        sec.run(4.5);   // double instead of int
    }
}

class sec {
    static double run(int a) {
        return a;
    }
}
