class Main { 
    static void run() {
        boolean a = "str"; // String to boolean
    }
}