class Main {
    static String a;
    static void run() {}
    static void run2(int a, double b) {
        Main.a = ifj16.sort(5.1); // invalid type of parameter
    }
}

