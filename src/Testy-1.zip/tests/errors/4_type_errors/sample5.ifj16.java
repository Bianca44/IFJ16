class Main {
    static void run() {
        ifj16.length(); // less parameters
    }
}
