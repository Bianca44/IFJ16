class Main {
    static void run() {
        String a;
        a = ifj16.length("str"); // lvalue is string
    }
}