class Main {
    static void run() {
        String a;
        a = 5.5;	// rvalue is double
    }
}
