class Main {
    static void run() {
        int a = 5;
        if(a) { // using integer as a logical operator

        }
        
    }
}