class Main {
    static void run() {}
    static void rtun(int a, double b) {
    	int c = 5;
        ifj16.compare("fdas", a); // invalid parameter type
    }
}
