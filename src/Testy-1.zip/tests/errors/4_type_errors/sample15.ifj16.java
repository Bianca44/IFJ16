class Main {
    static String a;
    static void run() {}
    static void r1un2(int a, double b) {
        Main.a = ifj16.substr("dsa"); // wrong number of parameters
    }
}

