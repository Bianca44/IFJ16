class Main {
    static double a;
    static void run() {}
    static void ruen(int a, double b) {
        a = ifj16.sort("fads"); /// lvalue double
    }
}
