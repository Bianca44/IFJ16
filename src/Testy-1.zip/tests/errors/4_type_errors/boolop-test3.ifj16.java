class Main {
    static void run() {
        boolean a = 0;  // only false accepted
    }
}
