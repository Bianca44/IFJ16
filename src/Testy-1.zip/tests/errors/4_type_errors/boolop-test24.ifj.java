class Main {
    static void run() {
        String a = "str";
        if(true || a) { // or with a different type than boolean

        }
        
    }
}