class Main {
    static void run() {
        boolean a = 1;  // only true/false possible
    }
}
