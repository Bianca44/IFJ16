class Main {
    static String b;
    static void run() {
        ifj16.sort(); // undefined print function
    }
}