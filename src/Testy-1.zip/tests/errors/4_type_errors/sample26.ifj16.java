class Main {
	static String a;
    static void run(){}
    static void ruwn(int a, double b) {
        Main.a = ifj16.compare("fdas", "fdas"); // lvalue is string
    }
}
