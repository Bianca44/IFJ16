class Main {
    static String a;
    static void run() {
        int a = ifj16.sort("fads"); /// lvalue int
    }
}

