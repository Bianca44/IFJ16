/*
 * See alse: https://wis.fit.vutbr.cz/FIT/st/phorum-msg-show.php?id=45642
 */

class Main {
    static void run() {
        ifj16.print("Ahoj\n");
    }
}

class Test {
    static void method() {
        String c = "str";
        return c; // returns string instead of nothing
    }
}
