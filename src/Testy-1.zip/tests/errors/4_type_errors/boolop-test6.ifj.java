class Main { 
    static void run() {
        int a = true; // boolean value to int
    }
}