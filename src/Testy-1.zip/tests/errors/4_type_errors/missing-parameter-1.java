class Main {
    static String b;
    static void run() {
        ifj16.print(); // undefined print function
    }
}