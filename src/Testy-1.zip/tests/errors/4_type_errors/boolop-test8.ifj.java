class Main { 
    static void run() {
        String a = false; // boolean value to String
    }
}