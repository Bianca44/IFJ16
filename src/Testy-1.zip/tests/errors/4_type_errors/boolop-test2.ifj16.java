class Main {
    static void run() {
        int a = true;  // 1
    }
}
