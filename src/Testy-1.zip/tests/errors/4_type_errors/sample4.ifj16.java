class Main {
    static void run() {
        String a = "tr";
        ifj16.find("str", a, 5); // too many parameters
    }
}
