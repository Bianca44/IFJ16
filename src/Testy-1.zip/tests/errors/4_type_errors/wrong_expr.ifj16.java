class Main {
    static void run() {
        if (5+4) {}
    }
}
