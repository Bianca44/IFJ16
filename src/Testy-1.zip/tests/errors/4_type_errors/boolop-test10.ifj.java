class Main { 
    static void run() {
        boolean a = 5.5; // double to boolean
    }
}