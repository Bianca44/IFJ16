class Main {
    static void run() {
        sec.run(4.5);   // calling with double instead of boolean parameter
    }
}

class sec {
    static String run(boolean a) {
        String c = "str";
        return c; 
    }
}