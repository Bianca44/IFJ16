class Main {
    static void run() {
        ifj16.print("Ahoj\n");
    }
}

class Test {
    static int method() {
        return 5.5; // returns double instead of int
    }
}
