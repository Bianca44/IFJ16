class Main {
    static void run() {
        sec.run("str");   // str instead of int
    }
}

class sec {
    static double run(int a) {
        return a;
    }
}
