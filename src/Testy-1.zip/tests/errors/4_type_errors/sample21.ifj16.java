class Main {
    static void run() {
        int a;
        a = 5.5;	// rvalue is double
    }
}