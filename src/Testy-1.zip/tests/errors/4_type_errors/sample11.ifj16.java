class Main {
    static String a;
    static void run() {}
    static void run2(int a, double b) {
        a = ifj16.readInt(a); // parameter a
    }
}

