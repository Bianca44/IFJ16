class Main {
    static void run() {
        ifj16.find(4, 18); // wrong constants
    }
}
