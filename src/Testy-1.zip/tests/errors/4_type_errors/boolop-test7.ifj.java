class Main { 
    static void run() {
        double a = true; // boolean value to double
    }
}