class Main {
    static void run() {
        int a;
        ifj16.length(a); // wrong type of parameters
    }
}
