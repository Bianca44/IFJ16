class Main {
    static double a;
    static void run(){}
    static void raun(int a, double b) {
        a = ifj16.sort("fads", "str"); /// more parameters
    }
}
