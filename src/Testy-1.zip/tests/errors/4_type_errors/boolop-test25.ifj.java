class Main {
    static void run() {
        String a = "str";
        if(true && a) { // and with a different type than boolean

        }
        
    }
}