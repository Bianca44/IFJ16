class Main {
    static String a;
    static void run(){}
    static void ru2n(int a, double b) {
        a = ifj16.substr("das",1,1);    // result must be string
    }
}

