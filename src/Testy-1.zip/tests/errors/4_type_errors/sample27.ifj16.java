class Main {
	static int a;
    static void run() {
        a = ifj16.find("str1"); // only one parameter
    }
}