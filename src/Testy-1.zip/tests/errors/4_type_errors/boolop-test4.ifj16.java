class Main {
    static void run() {
        String a = false;  // only true/false possible
    }
}
