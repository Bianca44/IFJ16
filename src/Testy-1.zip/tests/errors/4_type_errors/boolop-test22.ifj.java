class Main {
    static void run() {
        double a = 5.5;
        if(a) { // using double as a logical operator

        }
        
    }
}