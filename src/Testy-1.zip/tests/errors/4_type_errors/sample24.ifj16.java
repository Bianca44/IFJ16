class Main {
    static void run() {
        ifj16.length("str1", "str2"); // more parameters than 1
    }
}