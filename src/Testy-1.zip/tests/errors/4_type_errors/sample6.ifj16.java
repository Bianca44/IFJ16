class Main {
    static void run() {
        int a;
        double b;
        String c;
        sec.bar(1.2);
    }
    static int foo(int a, double b, String c) {
        return a + b;
    }
}

class sec {
    static int bar(int a){return a;}
}
