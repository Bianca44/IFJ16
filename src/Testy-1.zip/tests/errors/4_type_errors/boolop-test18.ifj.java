class Main {
    static void run() {
        sec.run(4);   // calling with int instead of boolean parameter
    }
}

class sec {
    static String run(boolean a) {
        String c = "str";
        return c; 
    }
}