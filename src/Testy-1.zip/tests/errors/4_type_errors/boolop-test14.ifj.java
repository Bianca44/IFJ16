class Main { 
    static void run() {
    	String b = "str";
        boolean a = b; // String to boolean
    }
}