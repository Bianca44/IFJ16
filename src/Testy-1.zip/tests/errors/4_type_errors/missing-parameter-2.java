class Main {
    static String b;
    static void run() {
        ifj16.find(); // undefined print function
    }
}